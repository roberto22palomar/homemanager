package com.example.homemanager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HomeManagerApplication {

	public static void main(String[] args) {
		SpringApplication.run(HomeManagerApplication.class, args);
	}

}
