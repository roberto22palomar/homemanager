package com.example.homemanager.utils;

public enum EstadoInvitacion {
    PENDIENTE, ACEPTADA, RECHAZADA
}
