package com.example.homemanager.utils;

public enum EstadoTarea {
    SIN_COMENZAR, EN_CURSO, FINALIZADA
}
