package com.example.homemanager.utils;

public enum InvitacionVigente {
    VIGENTE, FINALIZADA
}
