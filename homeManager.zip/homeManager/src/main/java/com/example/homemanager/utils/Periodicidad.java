package com.example.homemanager.utils;

public enum Periodicidad {
    DIARIA, SEMANAL, MENSUAL, ANUAL
}
