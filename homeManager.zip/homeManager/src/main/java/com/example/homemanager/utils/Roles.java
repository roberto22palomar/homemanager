package com.example.homemanager.utils;

public enum Roles {
    administrador, miembro
}
