package com.example.homemanager.utils.exceptions;

public class InvitacionFinalizadaException extends RuntimeException {


    public InvitacionFinalizadaException(String message) {
        super(message);
    }

}

