package com.example.homemanager.utils.exceptions;

public class UserAlreadyAddedInCasa extends RuntimeException {

    public UserAlreadyAddedInCasa(String message) {
        super(message);
    }

}
